package com.teste.attornatus.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/enderecos/{pessoaId}")
public class EnderecoController {

}
