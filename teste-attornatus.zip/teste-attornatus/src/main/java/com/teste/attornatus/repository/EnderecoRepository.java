package com.teste.attornatus.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.teste.attornatus.entity.Endereco;

public interface EnderecoRepository extends JpaRepository<Endereco, Long> {
}
